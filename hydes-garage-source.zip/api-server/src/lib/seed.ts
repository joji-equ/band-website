import { db, singlesTable, albumsTable, showsTable, aboutTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { logger } from "./logger";

const SINGLES = [
  {
    title: "Hyde's Garage - Ah! Ka thian",
    releaseDate: new Date("2020-09-25"),
    description: "Hyde's Garage first single. This quirky song is about our awkward first encounters with our crushes.",
    coverUrl: null as string | null,
    listenUrl: "https://www.youtube.com/watch?v=Xawiu4GwpTs",
  },
  {
    title: "Hyde's Garage x Manunmawii - Eighteen",
    releaseDate: new Date("2021-06-01"),
    description: "In this groovy single, Hyde's Garage highlights the struggles of coming-of-age adolescent phases.",
    coverUrl: null as string | null,
    listenUrl: "https://www.youtube.com/watch?v=wCx_s86s2bc",
  },
  {
    title: "Hyde's Garage x Ruatpuii - This too shall pass",
    releaseDate: new Date("2022-03-15"),
    description: "It's the festive season and Hyde's Garage with Ruatpuii highlights the joyous Christmas holidays and how it seems to go so fast when you spend it with the ones you love.",
    coverUrl: null as string | null,
    listenUrl: "https://www.youtube.com/watch?v=JTwycG-fqns",
  },
  {
    title: "Hyde's Garage x Hruaizeli - The Storm, the Calm and Whatnot",
    releaseDate: new Date("2023-02-10"),
    description: "Hyde's Garage (featuring Hruaizeli) explores themes of emotional struggle, resilience, and the cyclical nature of life's difficulties.",
    coverUrl: null as string | null,
    listenUrl: "https://www.youtube.com/watch?v=o0IQ2Ee2eds",
  },
  {
    title: "Hyde's Garage x This Chord - Car Song",
    releaseDate: new Date("2023-09-22"),
    description: "Hyde's Garage x This Chord captures a feeling of intimacy and escapism. The song's lyrics evoke a sense of wanting to pause time and disconnect from the outside world with someone special.",
    coverUrl: null as string | null,
    listenUrl: "https://www.youtube.com/watch?v=XAT1xnrP8b4",
  },
  {
    title: "Hyde's Garage, Samuel Apazozo - Say",
    releaseDate: new Date("2024-05-17"),
    description: "This indie-rap esque song explores the themes of nervousness, vulnerability, and the difficulty of expressing one's feelings in a budding relationship.",
    coverUrl: null as string | null,
    listenUrl: "https://www.youtube.com/watch?v=KVdUPmKORCk",
  },
];

const ALBUMS = [
  {
    title: "Airborne Deceptions",
    releaseDate: new Date("2025-08-14"),
    description:
      "The debut album of Hyde's Garage. This album explores themes of addiction and emotional dependency, portrayed through a fictional relationship. Ada describes something that feels beautiful at first slowly destroys you. The psychological cycle of dependency and self-betrayal.",
    coverUrl: null as string | null,
    listenUrl: "https://youtube.com/playlist?list=PLJc5bhfPLwWhWpjC04Ri2V6U4UEdPDMNl",
  },
];

const SHOWS = [
  {
    title: "Hatim HillFest",
    venue: "Hatim HillFest",
    city: "Kawmzawl, Lunglei",
    date: new Date("2024-04-04"),
    ticketUrl: null as string | null,
    notes: null as string | null,
  },
  {
    title: "Garage Sessions Vol. 4",
    venue: "14beans Cafe",
    city: "Aizawl",
    date: new Date("2026-05-09"),
    ticketUrl: null as string | null,
    notes: "Doors at 7pm. Bring earplugs and good vibes.",
  },
  {
    title: "North-East Indie Fest",
    venue: "Polo Ground",
    city: "Shillong",
    date: new Date("2026-06-06"),
    ticketUrl: "https://example.com/tickets",
    notes: "Co-headlining with three friends from across the hills.",
  },
  {
    title: "Bedroom to Bandstand Tour",
    venue: "Studio 7",
    city: "Guwahati",
    date: new Date("2026-07-04"),
    ticketUrl: null as string | null,
    notes: "Stripped down acoustic set, all new songs.",
  },
];

export async function seedDatabase() {
  try {
    logger.info("Seeding production database…");

    // Wipe and re-seed content tables on every deploy so the code is the source of truth
    await db.execute(sql`TRUNCATE singles RESTART IDENTITY CASCADE`);
    await db.insert(singlesTable).values(SINGLES);
    logger.info(`Seeded ${SINGLES.length} singles.`);

    await db.execute(sql`TRUNCATE albums RESTART IDENTITY CASCADE`);
    await db.insert(albumsTable).values(ALBUMS);
    logger.info(`Seeded ${ALBUMS.length} albums.`);

    await db.execute(sql`TRUNCATE shows RESTART IDENTITY CASCADE`);
    await db.insert(showsTable).values(SHOWS);
    logger.info(`Seeded ${SHOWS.length} shows.`);

    // Upsert about row — preserve any photo/bio edits, always sync social links
    const existing = await db.select().from(aboutTable);
    if (existing.length === 0) {
      await db.insert(aboutTable).values({
        bandName: "Hydes Garage",
        tagline: "Indie sensation from the hills of Mizoram",
        story:
          "Hydes Garage is an independent band from Serkawn, Mizoram. Formed in 2020, the band makes refreshing, lo-fi, heart-on-sleeve music defined by playful structures and a fearless DIY spirit. What started as a friends-only bedroom project quietly sparked a creative journey full of charm, chaos, and late-night recordings.",
        hometown: "Serkawn, Mizoram",
        foundedYear: 2020,
        photoUrl: null,
        youtubeUrl: "https://www.youtube.com/@hydesgarage",
        spotifyUrl: "https://open.spotify.com/artist/44qrg8E3Ett3lxLqNzkazN",
        instagramUrl: "https://www.instagram.com/hydesgarage?igsh=MTg2OXBhODF2ZGV4cw==",
      });
    } else {
      await db.execute(sql`
        UPDATE about SET
          band_name     = 'Hydes Garage',
          tagline       = 'Indie sensation from the hills of Mizoram',
          story         = 'Hydes Garage is an independent band from Serkawn, Mizoram. Formed in 2020, the band makes refreshing, lo-fi, heart-on-sleeve music defined by playful structures and a fearless DIY spirit. What started as a friends-only bedroom project quietly sparked a creative journey full of charm, chaos, and late-night recordings.',
          hometown      = 'Serkawn, Mizoram',
          founded_year  = 2020,
          youtube_url   = 'https://www.youtube.com/@hydesgarage',
          spotify_url   = 'https://open.spotify.com/artist/44qrg8E3Ett3lxLqNzkazN',
          instagram_url = 'https://www.instagram.com/hydesgarage?igsh=MTg2OXBhODF2ZGV4cw=='
        WHERE id = (SELECT id FROM about LIMIT 1)
      `);
    }
    logger.info("About row synced.");

    logger.info("Production seed complete.");
  } catch (err) {
    logger.error({ err }, "Database seed failed — continuing anyway.");
  }
}
