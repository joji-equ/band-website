import session, { type SessionOptions } from "express-session";
import type { RequestHandler } from "express";

const sessionSecret = process.env["SESSION_SECRET"];

if (!sessionSecret) {
  throw new Error("SESSION_SECRET environment variable is required.");
}

const sessionOptions: SessionOptions = {
  name: "hg.sid",
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    path: "/",
    maxAge: 1000 * 60 * 60 * 24 * 7,
  },
};

export const sessionMiddleware: RequestHandler = session(sessionOptions);

declare module "express-session" {
  interface SessionData {
    user?: {
      username: string;
    };
  }
}
