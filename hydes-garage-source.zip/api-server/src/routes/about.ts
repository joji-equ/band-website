import { Router, type IRouter } from "express";
import { db, aboutTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { UpdateAboutBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

function serializeAbout(row: typeof aboutTable.$inferSelect) {
  return {
    id: row.id,
    bandName: row.bandName,
    tagline: row.tagline,
    story: row.story,
    hometown: row.hometown,
    foundedYear: row.foundedYear,
    photoUrl: row.photoUrl,
    youtubeUrl: row.youtubeUrl,
    spotifyUrl: row.spotifyUrl,
    instagramUrl: row.instagramUrl,
    updatedAt: row.updatedAt.toISOString(),
  };
}

const DEFAULT_ABOUT = {
  bandName: "Hydes Garage",
  tagline: "indie sensation from the garage",
  story:
    "We are Hydes Garage, an independent band from Serkawn, Mizoram. We make scrappy, lo-fi, heart-on-sleeve music in bedrooms and back rooms.",
  hometown: "Serkawn, Mizoram",
  foundedYear: 2020,
  photoUrl: null as string | null,
  youtubeUrl: null as string | null,
  spotifyUrl: null as string | null,
  instagramUrl: null as string | null,
};

async function ensureAbout() {
  const rows = await db.select().from(aboutTable).limit(1);
  if (rows[0]) return rows[0];
  const [row] = await db.insert(aboutTable).values(DEFAULT_ABOUT).returning();
  return row;
}

router.get("/about", async (_req, res) => {
  const row = await ensureAbout();
  res.json(serializeAbout(row));
});

router.put("/about", requireAuth, async (req, res) => {
  const parsed = UpdateAboutBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid about payload" });
    return;
  }
  const existing = await ensureAbout();
  const [row] = await db
    .update(aboutTable)
    .set({
      bandName: parsed.data.bandName,
      tagline: parsed.data.tagline,
      story: parsed.data.story,
      hometown: parsed.data.hometown,
      foundedYear: parsed.data.foundedYear,
      photoUrl: parsed.data.photoUrl ?? null,
      youtubeUrl: parsed.data.youtubeUrl ?? null,
      spotifyUrl: parsed.data.spotifyUrl ?? null,
      instagramUrl: parsed.data.instagramUrl ?? null,
      updatedAt: new Date(),
    })
    .where(eq(aboutTable.id, existing.id))
    .returning();
  res.json(serializeAbout(row));
});

export default router;
