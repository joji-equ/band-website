import { Router, type IRouter } from "express";
import { db, albumsTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import {
  CreateAlbumBody,
  GetAlbumParams,
  UpdateAlbumBody,
  UpdateAlbumParams,
  DeleteAlbumParams,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

function serializeAlbum(row: typeof albumsTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    releaseDate: row.releaseDate.toISOString(),
    description: row.description,
    coverUrl: row.coverUrl,
    listenUrl: row.listenUrl,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/albums", async (_req, res) => {
  const rows = await db
    .select()
    .from(albumsTable)
    .orderBy(desc(albumsTable.releaseDate));
  res.json(rows.map(serializeAlbum));
});

router.get("/albums/:id", async (req, res) => {
  const params = GetAlbumParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [row] = await db
    .select()
    .from(albumsTable)
    .where(eq(albumsTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Album not found" });
    return;
  }
  res.json(serializeAlbum(row));
});

router.post("/albums", requireAuth, async (req, res) => {
  const parsed = CreateAlbumBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid album payload" });
    return;
  }
  const [row] = await db
    .insert(albumsTable)
    .values({
      title: parsed.data.title,
      releaseDate: new Date(parsed.data.releaseDate),
      description: parsed.data.description,
      coverUrl: parsed.data.coverUrl ?? null,
      listenUrl: parsed.data.listenUrl ?? null,
    })
    .returning();
  res.status(201).json(serializeAlbum(row));
});

router.patch("/albums/:id", requireAuth, async (req, res) => {
  const params = UpdateAlbumParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const parsed = UpdateAlbumBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid album payload" });
    return;
  }
  const [row] = await db
    .update(albumsTable)
    .set({
      title: parsed.data.title,
      releaseDate: new Date(parsed.data.releaseDate),
      description: parsed.data.description,
      coverUrl: parsed.data.coverUrl ?? null,
      listenUrl: parsed.data.listenUrl ?? null,
    })
    .where(eq(albumsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Album not found" });
    return;
  }
  res.json(serializeAlbum(row));
});

router.delete("/albums/:id", requireAuth, async (req, res) => {
  const params = DeleteAlbumParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await db.delete(albumsTable).where(eq(albumsTable.id, params.data.id));
  res.status(204).end();
});

export default router;
