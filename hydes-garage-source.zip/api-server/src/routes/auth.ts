import { Router, type IRouter } from "express";
import { LoginBody } from "@workspace/api-zod";

const router: IRouter = Router();

const ADMIN_USERNAME = process.env["ADMIN_USERNAME"];
const ADMIN_PASSWORD = process.env["ADMIN_PASSWORD"];

if (!ADMIN_USERNAME || !ADMIN_PASSWORD) {
  throw new Error(
    "ADMIN_USERNAME and ADMIN_PASSWORD environment variables are required.",
  );
}

router.post("/auth/login", (req, res) => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid login payload" });
    return;
  }

  const { username, password } = parsed.data;
  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  req.session.user = { username };
  req.session.save((err) => {
    if (err) {
      req.log.error({ err }, "session save failed");
      res.status(500).json({ error: "Could not start session" });
      return;
    }
    res.json({ authenticated: true, username });
  });
});

router.post("/auth/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      req.log.error({ err }, "session destroy failed");
    }
    res.clearCookie("hg.sid");
    res.json({ authenticated: false, username: null });
  });
});

router.get("/auth/me", (req, res) => {
  if (req.session?.user) {
    res.json({
      authenticated: true,
      username: req.session.user.username,
    });
    return;
  }
  res.json({ authenticated: false, username: null });
});

export default router;
