import { Router } from "express";
import archiver from "archiver";
import path from "path";
import fs from "fs";

const router = Router();

// process.cwd() is the api-server package dir; workspace root is two levels up
const ROOT = path.resolve(process.cwd(), "../..");

function addDirectory(archive: archiver.Archiver, diskPath: string, zipPath: string) {
  if (!fs.existsSync(diskPath)) return;
  archive.glob("**/*", {
    cwd: diskPath,
    dot: false,
    ignore: [
      "**/node_modules/**",
      "**/dist/**",
      "**/.local/**",
      "**/*.map",
      "**/.git/**",
    ],
  }, { prefix: zipPath });
}

function addFile(archive: archiver.Archiver, diskPath: string, zipName: string) {
  if (!fs.existsSync(diskPath)) return;
  archive.file(diskPath, { name: zipName });
}

router.get("/", (_req, res) => {
  res.setHeader("Content-Disposition", 'attachment; filename="hydes-garage-source.zip"');
  res.setHeader("Content-Type", "application/zip");

  const archive = archiver("zip", { zlib: { level: 6 } });

  archive.on("error", (err) => {
    if (!res.headersSent) res.status(500).json({ error: "Failed to create archive" });
    else res.end();
  });

  archive.pipe(res);

  addDirectory(archive, path.join(ROOT, "artifacts/web/src"), "web/src");
  addFile(archive, path.join(ROOT, "artifacts/web/index.html"), "web/index.html");
  addFile(archive, path.join(ROOT, "artifacts/web/package.json"), "web/package.json");
  addFile(archive, path.join(ROOT, "artifacts/web/vite.config.ts"), "web/vite.config.ts");
  addFile(archive, path.join(ROOT, "artifacts/web/tsconfig.json"), "web/tsconfig.json");

  addDirectory(archive, path.join(ROOT, "artifacts/api-server/src"), "api-server/src");
  addFile(archive, path.join(ROOT, "artifacts/api-server/package.json"), "api-server/package.json");
  addFile(archive, path.join(ROOT, "artifacts/api-server/tsconfig.json"), "api-server/tsconfig.json");

  addDirectory(archive, path.join(ROOT, "lib"), "lib");

  addFile(archive, path.join(ROOT, "package.json"), "package.json");
  addFile(archive, path.join(ROOT, "pnpm-workspace.yaml"), "pnpm-workspace.yaml");
  addFile(archive, path.join(ROOT, "tsconfig.json"), "tsconfig.json");

  archive.finalize();
});

export default router;
