import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import showsRouter from "./shows";
import albumsRouter from "./albums";
import singlesRouter from "./singles";
import aboutRouter from "./about";
import summaryRouter from "./summary";
import downloadRouter from "./download";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(showsRouter);
router.use(albumsRouter);
router.use(singlesRouter);
router.use(aboutRouter);
router.use(summaryRouter);
router.use("/download/source", downloadRouter);

export default router;
