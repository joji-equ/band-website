import { Router, type IRouter } from "express";
import { db, showsTable } from "@workspace/db";
import { asc, desc, eq, gte } from "drizzle-orm";
import {
  CreateShowBody,
  GetShowParams,
  UpdateShowBody,
  UpdateShowParams,
  DeleteShowParams,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

function serializeShow(row: typeof showsTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    venue: row.venue,
    city: row.city,
    date: row.date.toISOString(),
    ticketUrl: row.ticketUrl,
    notes: row.notes,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/shows", async (_req, res) => {
  const rows = await db.select().from(showsTable).orderBy(desc(showsTable.date));
  res.json(rows.map(serializeShow));
});

router.get("/shows/upcoming", async (_req, res) => {
  const now = new Date();
  const rows = await db
    .select()
    .from(showsTable)
    .where(gte(showsTable.date, now))
    .orderBy(asc(showsTable.date));
  res.json(rows.map(serializeShow));
});

router.get("/shows/:id", async (req, res) => {
  const params = GetShowParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [row] = await db
    .select()
    .from(showsTable)
    .where(eq(showsTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Show not found" });
    return;
  }
  res.json(serializeShow(row));
});

router.post("/shows", requireAuth, async (req, res) => {
  const parsed = CreateShowBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid show payload" });
    return;
  }
  const [row] = await db
    .insert(showsTable)
    .values({
      title: parsed.data.title,
      venue: parsed.data.venue,
      city: parsed.data.city,
      date: new Date(parsed.data.date),
      ticketUrl: parsed.data.ticketUrl ?? null,
      notes: parsed.data.notes ?? null,
    })
    .returning();
  res.status(201).json(serializeShow(row));
});

router.patch("/shows/:id", requireAuth, async (req, res) => {
  const params = UpdateShowParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const parsed = UpdateShowBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid show payload" });
    return;
  }
  const [row] = await db
    .update(showsTable)
    .set({
      title: parsed.data.title,
      venue: parsed.data.venue,
      city: parsed.data.city,
      date: new Date(parsed.data.date),
      ticketUrl: parsed.data.ticketUrl ?? null,
      notes: parsed.data.notes ?? null,
    })
    .where(eq(showsTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Show not found" });
    return;
  }
  res.json(serializeShow(row));
});

router.delete("/shows/:id", requireAuth, async (req, res) => {
  const params = DeleteShowParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await db.delete(showsTable).where(eq(showsTable.id, params.data.id));
  res.status(204).end();
});

export default router;
