import { Router, type IRouter } from "express";
import { db, singlesTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import {
  CreateSingleBody,
  GetSingleParams,
  UpdateSingleBody,
  UpdateSingleParams,
  DeleteSingleParams,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";

const router: IRouter = Router();

function serializeSingle(row: typeof singlesTable.$inferSelect) {
  return {
    id: row.id,
    title: row.title,
    releaseDate: row.releaseDate.toISOString(),
    description: row.description,
    coverUrl: row.coverUrl,
    listenUrl: row.listenUrl,
    createdAt: row.createdAt.toISOString(),
  };
}

router.get("/singles", async (_req, res) => {
  const rows = await db
    .select()
    .from(singlesTable)
    .orderBy(desc(singlesTable.releaseDate));
  res.json(rows.map(serializeSingle));
});

router.get("/singles/:id", async (req, res) => {
  const params = GetSingleParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const [row] = await db
    .select()
    .from(singlesTable)
    .where(eq(singlesTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Single not found" });
    return;
  }
  res.json(serializeSingle(row));
});

router.post("/singles", requireAuth, async (req, res) => {
  const parsed = CreateSingleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid single payload" });
    return;
  }
  const [row] = await db
    .insert(singlesTable)
    .values({
      title: parsed.data.title,
      releaseDate: new Date(parsed.data.releaseDate),
      description: parsed.data.description,
      coverUrl: parsed.data.coverUrl ?? null,
      listenUrl: parsed.data.listenUrl ?? null,
    })
    .returning();
  res.status(201).json(serializeSingle(row));
});

router.patch("/singles/:id", requireAuth, async (req, res) => {
  const params = UpdateSingleParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  const parsed = UpdateSingleBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid single payload" });
    return;
  }
  const [row] = await db
    .update(singlesTable)
    .set({
      title: parsed.data.title,
      releaseDate: new Date(parsed.data.releaseDate),
      description: parsed.data.description,
      coverUrl: parsed.data.coverUrl ?? null,
      listenUrl: parsed.data.listenUrl ?? null,
    })
    .where(eq(singlesTable.id, params.data.id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "Single not found" });
    return;
  }
  res.json(serializeSingle(row));
});

router.delete("/singles/:id", requireAuth, async (req, res) => {
  const params = DeleteSingleParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }
  await db.delete(singlesTable).where(eq(singlesTable.id, params.data.id));
  res.status(204).end();
});

export default router;
