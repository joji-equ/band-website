import { Router, type IRouter } from "express";
import {
  db,
  showsTable,
  albumsTable,
  singlesTable,
} from "@workspace/db";
import { asc, gte, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/summary", async (_req, res) => {
  const now = new Date();

  const [showCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(showsTable);
  const [albumCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(albumsTable);
  const [singleCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(singlesTable);
  const [upcomingCountRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(showsTable)
    .where(gte(showsTable.date, now));

  const [nextShowRow] = await db
    .select()
    .from(showsTable)
    .where(gte(showsTable.date, now))
    .orderBy(asc(showsTable.date))
    .limit(1);

  res.json({
    showCount: showCountRow?.count ?? 0,
    albumCount: albumCountRow?.count ?? 0,
    singleCount: singleCountRow?.count ?? 0,
    upcomingShowCount: upcomingCountRow?.count ?? 0,
    nextShow: nextShowRow
      ? {
          id: nextShowRow.id,
          title: nextShowRow.title,
          venue: nextShowRow.venue,
          city: nextShowRow.city,
          date: nextShowRow.date.toISOString(),
          ticketUrl: nextShowRow.ticketUrl,
          notes: nextShowRow.notes,
          createdAt: nextShowRow.createdAt.toISOString(),
        }
      : null,
  });
});

export default router;
