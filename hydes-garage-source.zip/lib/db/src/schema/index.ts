import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
} from "drizzle-orm/pg-core";

export const showsTable = pgTable("shows", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  venue: text("venue").notNull(),
  city: text("city").notNull(),
  date: timestamp("date", { withTimezone: true }).notNull(),
  ticketUrl: text("ticket_url"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type ShowRow = typeof showsTable.$inferSelect;

export const albumsTable = pgTable("albums", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  releaseDate: timestamp("release_date", { withTimezone: true }).notNull(),
  description: text("description").notNull(),
  coverUrl: text("cover_url"),
  listenUrl: text("listen_url"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type AlbumRow = typeof albumsTable.$inferSelect;

export const singlesTable = pgTable("singles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  releaseDate: timestamp("release_date", { withTimezone: true }).notNull(),
  description: text("description").notNull(),
  coverUrl: text("cover_url"),
  listenUrl: text("listen_url"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type SingleRow = typeof singlesTable.$inferSelect;

export const aboutTable = pgTable("about", {
  id: serial("id").primaryKey(),
  bandName: text("band_name").notNull(),
  tagline: text("tagline").notNull(),
  story: text("story").notNull(),
  hometown: text("hometown").notNull(),
  foundedYear: integer("founded_year").notNull(),
  photoUrl: text("photo_url"),
  youtubeUrl: text("youtube_url"),
  spotifyUrl: text("spotify_url"),
  instagramUrl: text("instagram_url"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type AboutRow = typeof aboutTable.$inferSelect;
