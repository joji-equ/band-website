import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { SiteBackground } from "@/components/layout/SiteBackground";

import Home from "@/pages/home";
import Shows from "@/pages/shows";
import Music from "@/pages/music";
import About from "@/pages/about";
import Login from "@/pages/admin/login";
import Dashboard from "@/pages/admin/dashboard";
import AdminShows from "@/pages/admin/shows";
import AdminAlbums from "@/pages/admin/albums";
import AdminSingles from "@/pages/admin/singles";
import AdminAbout from "@/pages/admin/about";

import { useGetMe } from "@workspace/api-client-react";

const queryClient = new QueryClient();

function AdminGuard({ children }: { children: React.ReactNode }) {
  const { data, isLoading } = useGetMe();

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div></div>;
  }

  if (!data?.authenticated) {
    return <Redirect to="/admin/login" />;
  }

  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/shows" component={Shows} />
      <Route path="/music" component={Music} />
      <Route path="/about" component={About} />
      
      <Route path="/admin/login" component={Login} />
      
      <Route path="/admin">
        <AdminGuard><Dashboard /></AdminGuard>
      </Route>
      <Route path="/admin/shows">
        <AdminGuard><AdminShows /></AdminGuard>
      </Route>
      <Route path="/admin/albums">
        <AdminGuard><AdminAlbums /></AdminGuard>
      </Route>
      <Route path="/admin/singles">
        <AdminGuard><AdminSingles /></AdminGuard>
      </Route>
      <Route path="/admin/about">
        <AdminGuard><AdminAbout /></AdminGuard>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SiteBackground />
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
