import { Link, useLocation } from "wouter";
import { useLogout, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut } from "lucide-react";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const logout = useLogout();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        setLocation("/");
      }
    });
  };

  const navItems = [
    { href: "/admin", label: "Dashboard" },
    { href: "/admin/shows", label: "Shows" },
    { href: "/admin/albums", label: "Albums" },
    { href: "/admin/singles", label: "Singles" },
    { href: "/admin/about", label: "About Info" },
  ];

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-sans">
      <header className="bg-primary text-black p-4 border-b-4 border-white flex flex-col sm:flex-row justify-between items-center gap-4 relative z-10 shadow-[0_4px_0_0_#fff]">
        <div className="flex items-center gap-4">
          <h1 className="font-display text-2xl uppercase tracking-widest bg-black text-white px-3 py-1 -rotate-2">
            <Link href="/admin">HG ADMIN</Link>
          </h1>
          <span className="text-sm font-bold uppercase tracking-widest hidden sm:inline-block">Zine Backoffice</span>
        </div>
        
        <nav className="flex items-center gap-2 flex-wrap justify-center">
          {navItems.map(item => (
            <Link 
              key={item.href} 
              href={item.href}
              className={`px-3 py-1 border-2 border-black font-bold uppercase tracking-wider text-xs sm:text-sm transition-all
                ${location === item.href ? 'bg-black text-white shadow-[2px_2px_0_0_#fff] rotate-1' : 'bg-white hover:bg-accent text-black shadow-[2px_2px_0_0_#000] -rotate-1 hover:translate-y-[1px] hover:shadow-[1px_1px_0_0_#000]'}`}
            >
              {item.label}
            </Link>
          ))}
          
          <button 
            onClick={handleLogout}
            className="flex items-center gap-1 px-3 py-1 bg-destructive text-white border-2 border-black font-bold uppercase tracking-wider text-xs sm:text-sm shadow-[2px_2px_0_0_#000] hover:bg-red-700 transition-all ml-2"
          >
            <LogOut className="w-3 h-3" /> EXIT
          </button>
        </nav>
      </header>

      <main className="flex-1 p-6 max-w-6xl mx-auto w-full">
        {children}
      </main>
    </div>
  );
}
