import { Link, useLocation } from "wouter";
import { useEffect, useRef, useState } from "react";
import heroArt from "@assets/concept-art_1777224798548.jpeg";

export function Navbar() {
  const [location] = useLocation();
  const headerRef = useRef<HTMLElement | null>(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    const el = headerRef.current;
    if (!el) return;
    let frame = 0;
    const onMove = (e: MouseEvent) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const rect = el.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        setParallax({ x: px, y: py });
      });
    };
    const onLeave = () => setParallax({ x: 0, y: 0 });
    el.addEventListener("mousemove", onMove);
    el.addEventListener("mouseleave", onLeave);
    return () => {
      cancelAnimationFrame(frame);
      el.removeEventListener("mousemove", onMove);
      el.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  return (
    <header
      ref={headerRef}
      className="relative overflow-hidden text-white pt-16 pb-12 px-4 text-center border-b-8 border-dashed border-black -rotate-1 mb-8 z-10 min-h-[55vh] sm:min-h-[60vh] flex flex-col justify-center"
    >
      {/* Background image with parallax */}
      <div
        className="absolute inset-0 -m-8 bg-cover bg-center transition-transform duration-200 ease-out will-change-transform"
        style={{
          backgroundImage: `url(${heroArt})`,
          transform: `scale(${hovered ? 1.08 : 1.04}) translate(${parallax.x * -20}px, ${parallax.y * -20}px)`,
        }}
      />
      {/* Dark scrim for legibility */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/70 pointer-events-none" />
      {/* Film grain / dotted texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30 mix-blend-overlay"
        style={{
          backgroundImage:
            "radial-gradient(rgba(255,255,255,0.6) 1px, transparent 1px)",
          backgroundSize: "3px 3px",
        }}
      />

      <div className="relative z-10">
        <h1
          className="font-display text-5xl md:text-7xl m-0 tracking-wide uppercase drop-shadow-[4px_4px_0px_rgba(0,0,0,0.85)] cursor-pointer transition-transform duration-300 hover:scale-[1.03] hover:-rotate-1"
          onMouseEnter={() => setHovered(true)}
          onMouseLeave={() => setHovered(false)}
        >
          <Link href="/">Hydes Garage</Link>
        </h1>
        <p className="mt-3 text-base sm:text-xl font-bold tracking-widest uppercase text-white/90 drop-shadow-[2px_2px_0px_rgba(0,0,0,0.7)]">
          indie sensation from the hills of Mizoram
        </p>

        <nav className="mt-8 flex justify-center gap-3 sm:gap-4 flex-wrap max-w-2xl mx-auto">
          <Link
            href="/shows"
            className={`zine-button px-4 py-2 rotate-2 transition-transform hover:scale-110 hover:-rotate-2 ${
              location === "/shows" ? "bg-primary" : ""
            }`}
          >
            Tour Chaos
          </Link>
          <Link
            href="/music"
            className={`zine-button px-4 py-2 -rotate-2 transition-transform hover:scale-110 hover:rotate-2 ${
              location === "/music" ? "bg-primary" : ""
            }`}
          >
            Music
          </Link>
          <Link
            href="/about"
            className={`zine-button px-4 py-2 rotate-1 transition-transform hover:scale-110 hover:-rotate-1 ${
              location === "/about" ? "bg-primary" : ""
            }`}
          >
            The Band
          </Link>
        </nav>
      </div>
    </header>
  );
}

export function Footer() {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const downloadUrl = `${base}/api/download/source`;

  return (
    <footer className="text-center p-8 bg-black border-t-4 border-dashed border-accent mt-16 text-muted-foreground text-sm font-bold tracking-wider uppercase">
      <p>Indie Forever • Made with love & noise</p>
      <div className="mt-4">
        <a
          href={downloadUrl}
          download="hydes-garage-source.zip"
          className="inline-block px-4 py-2 border-2 border-dashed border-muted-foreground hover:border-accent hover:text-accent transition-colors text-xs tracking-widest"
        >
          ⬇ Download Source Code
        </a>
      </div>
    </footer>
  );
}
