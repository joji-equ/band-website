import { useEffect, useRef, useState } from "react";
import bg1 from "@assets/single_1_1777225042444.jpg";
import bg2 from "@assets/single_2_1777225042445.jpg";
import bg3 from "@assets/single_3_1777225042445.jpg";
import bg4 from "@assets/single_4_1777225042446.jpg";
import bg5 from "@assets/single_5_1777225042446.jpg";
import bg6 from "@assets/single_6_1777225042447.jpg";

type Piece = {
  src: string;
  left: string;
  top: string;
  width: string;
  rotate: number;
  depth: number;
  tape: string;
  tapeRotate: number;
  delay: string;
};

const PIECES: Piece[] = [
  { src: bg1, left: "6%",  top: "8%",  width: "16rem", rotate: -8, depth: 0.9, tape: "rgba(255,236,138,0.8)", tapeRotate: -8, delay: "0s" },
  { src: bg2, left: "22%", top: "62%", width: "13rem", rotate: 6,  depth: 0.6, tape: "rgba(186,255,201,0.85)", tapeRotate: 6,  delay: "0.6s" },
  { src: bg3, left: "44%", top: "18%", width: "12rem", rotate: 9,  depth: 1.1, tape: "rgba(255,110,199,0.7)",  tapeRotate: -3, delay: "1.2s" },
  { src: bg4, left: "60%", top: "70%", width: "14rem", rotate: -5, depth: 0.7, tape: "rgba(255,236,138,0.8)", tapeRotate: 9,  delay: "0.3s" },
  { src: bg5, left: "78%", top: "12%", width: "15rem", rotate: 4,  depth: 1.0, tape: "rgba(186,255,201,0.85)", tapeRotate: -7, delay: "0.9s" },
  { src: bg6, left: "88%", top: "55%", width: "12rem", rotate: -3, depth: 0.55, tape: "rgba(255,110,199,0.7)", tapeRotate: 5,  delay: "1.5s" },
];

export function SiteBackground() {
  const ref = useRef<HTMLDivElement | null>(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    let frame = 0;
    const onMove = (e: MouseEvent) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const px = e.clientX / window.innerWidth - 0.5;
        const py = e.clientY / window.innerHeight - 0.5;
        setParallax({ x: px, y: py });
      });
    };
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden
      className="fixed inset-0 -z-10 overflow-hidden pointer-events-none"
    >
      {/* Painted base — moody indie wash */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 20% 10%, #2a2540 0%, #181423 55%, #0a0810 100%)",
        }}
      />

      {/* Scattered polaroid collage */}
      <div className="absolute inset-0">
        {PIECES.map((p, i) => {
          const tx = parallax.x * -50 * p.depth;
          const ty = parallax.y * -50 * p.depth - scrollY * 0.08 * p.depth;
          return (
            <div
              key={i}
              className="absolute"
              style={{
                left: p.left,
                top: p.top,
                width: p.width,
                transform: `translate(calc(-50% + ${tx}px), calc(-50% + ${ty}px)) rotate(${p.rotate}deg)`,
                animation: `zine-float 7s ease-in-out ${p.delay} infinite`,
                opacity: 0.55,
                filter: "saturate(0.85) contrast(0.95)",
              }}
            >
              <div
                className="absolute -top-3 left-1/2 w-16 h-5 z-10"
                style={{
                  background: p.tape,
                  transform: `translateX(-50%) rotate(${p.tapeRotate}deg)`,
                  boxShadow: "0 1px 0 rgba(0,0,0,0.15)",
                }}
              />
              <div className="bg-white p-2 pb-6 border border-black/30 shadow-[6px_6px_0px_rgba(0,0,0,0.55)]">
                <div className="aspect-[4/3] overflow-hidden bg-black">
                  <img
                    src={p.src}
                    alt=""
                    className="w-full h-full object-cover"
                    draggable={false}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Halftone dot texture */}
      <div
        className="absolute inset-0 opacity-25 mix-blend-overlay"
        style={{
          backgroundImage:
            "radial-gradient(rgba(255,255,255,0.7) 1px, transparent 1.2px)",
          backgroundSize: "4px 4px",
        }}
      />
      {/* Diagonal scribble lines */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg, transparent 0 18px, rgba(255,255,255,0.4) 18px 19px)",
        }}
      />
      {/* Vignette + dark wash so foreground stays legible */}
      <div className="absolute inset-0 bg-black/55" />
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,0.55) 100%)",
        }}
      />
    </div>
  );
}
