function pad(n: number): string {
  return String(n).padStart(2, "0");
}

function formatGoogleDate(d: Date): string {
  return (
    d.getUTCFullYear().toString() +
    pad(d.getUTCMonth() + 1) +
    pad(d.getUTCDate()) +
    "T" +
    pad(d.getUTCHours()) +
    pad(d.getUTCMinutes()) +
    pad(d.getUTCSeconds()) +
    "Z"
  );
}

export function buildGoogleCalendarUrl(opts: {
  title: string;
  start: Date | string;
  durationMinutes?: number;
  location?: string;
  details?: string;
}): string {
  const start = typeof opts.start === "string" ? new Date(opts.start) : opts.start;
  const end = new Date(start.getTime() + (opts.durationMinutes ?? 120) * 60 * 1000);
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: opts.title,
    dates: `${formatGoogleDate(start)}/${formatGoogleDate(end)}`,
  });
  if (opts.location) params.set("location", opts.location);
  if (opts.details) params.set("details", opts.details);
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}
