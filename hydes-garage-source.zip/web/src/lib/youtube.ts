function parseYouTubeUrl(url: string | null | undefined): URL | null {
  if (!url) return null;
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./, "");
    if (
      host === "youtu.be" ||
      host === "youtube.com" ||
      host === "m.youtube.com" ||
      host === "music.youtube.com"
    ) {
      return u;
    }
    return null;
  } catch {
    return null;
  }
}

export function getYouTubePlaylistId(url: string | null | undefined): string | null {
  const u = parseYouTubeUrl(url);
  if (!u) return null;
  const list = u.searchParams.get("list");
  if (!list) return null;
  if (list.startsWith("RD") || list.startsWith("UL")) return null;
  return list;
}

export function getYouTubeId(url: string | null | undefined): string | null {
  const u = parseYouTubeUrl(url);
  if (!u) return null;
  const host = u.hostname.replace(/^www\./, "");
  if (host === "youtu.be") {
    const id = u.pathname.slice(1).split("/")[0];
    return id || null;
  }
  if (u.pathname === "/watch") return u.searchParams.get("v");
  const parts = u.pathname.split("/").filter(Boolean);
  if (parts[0] === "embed" || parts[0] === "shorts" || parts[0] === "live") {
    return parts[1] || null;
  }
  return null;
}

export function getYouTubeEmbedUrl(url: string | null | undefined): string | null {
  const playlistId = getYouTubePlaylistId(url);
  if (playlistId) {
    return `https://www.youtube.com/embed/videoseries?list=${playlistId}`;
  }
  const id = getYouTubeId(url);
  return id ? `https://www.youtube.com/embed/${id}` : null;
}
