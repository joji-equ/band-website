import { Navbar, Footer } from "@/components/layout/Navbar";
import { useGetAbout } from "@workspace/api-client-react";
import bandPhoto from "@assets/band-photo_1777222042649.png";

export default function About() {
  const { data: about, isLoading } = useGetAbout();

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden">
      <Navbar />
      
      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-12">
        {isLoading ? (
           <div className="flex justify-center p-12">
              <div className="animate-spin h-12 w-12 border-8 border-accent border-t-black rounded-full"></div>
            </div>
        ) : about ? (
          <div className="bg-card text-card-foreground border-4 border-white p-8 md:p-12 shadow-[12px_12px_0px_0px_#ff6ec7] -rotate-1 relative">
            {/* Tape decorations */}
            <div className="absolute top-0 left-10 w-20 h-6 bg-yellow-200/50 -rotate-3 -translate-y-3 z-10"></div>
            <div className="absolute bottom-0 right-10 w-20 h-6 bg-yellow-200/50 rotate-3 translate-y-3 z-10"></div>
            
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="w-full md:w-1/2 flex-shrink-0">
                <div className="polaroid rotate-2">
                  <div className="border-4 border-black mb-3 h-64 overflow-hidden bg-white">
                     <img src={about.photoUrl || bandPhoto} alt={about.bandName} className="w-full h-full object-cover grayscale contrast-125 brightness-110" />
                  </div>
                  <div className="uppercase tracking-widest">{about.hometown} • EST. {about.foundedYear}</div>
                </div>
              </div>
              
              <div className="w-full md:w-1/2">
                <h2 className="font-display text-5xl text-accent uppercase mb-2">{about.bandName}</h2>
                <h3 className="text-xl font-bold bg-primary text-black inline-block px-3 py-1 mb-6 -rotate-2 border-2 border-black">{about.tagline}</h3>
                
                <div className="prose prose-invert max-w-none prose-p:font-sans prose-p:text-lg prose-p:leading-relaxed whitespace-pre-wrap">
                  {about.story}
                </div>
                
                <div className="mt-8 pt-6 border-t-4 border-dashed border-gray-600">
                  <h4 className="font-display text-2xl uppercase mb-4 text-secondary">Find Us</h4>
                  <div className="flex flex-wrap gap-4">
                    {about.youtubeUrl && <a href={about.youtubeUrl} target="_blank" rel="noreferrer" className="zine-button px-4 py-2">YouTube</a>}
                    {about.spotifyUrl && <a href={about.spotifyUrl} target="_blank" rel="noreferrer" className="zine-button px-4 py-2">Spotify</a>}
                    {about.instagramUrl && <a href={about.instagramUrl} target="_blank" rel="noreferrer" className="zine-button px-4 py-2">Instagram</a>}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
           <div className="text-center p-12 bg-card border-4 border-white rotate-1">
             <h2 className="font-display text-4xl text-primary">Band info not found.</h2>
           </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
}
