import { useEffect } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useGetAbout, useUpdateAbout, getGetAboutQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const aboutSchema = z.object({
  bandName: z.string().min(1, "Required"),
  tagline: z.string().min(1, "Required"),
  story: z.string().min(1, "Required"),
  hometown: z.string().min(1, "Required"),
  foundedYear: z.coerce.number().int().min(1900),
  photoUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  youtubeUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  spotifyUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  instagramUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

type AboutForm = z.infer<typeof aboutSchema>;

export default function AdminAbout() {
  const queryClient = useQueryClient();
  const { data: about, isLoading } = useGetAbout();
  const updateAbout = useUpdateAbout();

  const form = useForm<AboutForm>({
    resolver: zodResolver(aboutSchema),
    defaultValues: {
      bandName: "", tagline: "", story: "", hometown: "", foundedYear: 2020,
      photoUrl: "", youtubeUrl: "", spotifyUrl: "", instagramUrl: ""
    }
  });

  useEffect(() => {
    if (about) {
      form.reset({
        bandName: about.bandName,
        tagline: about.tagline,
        story: about.story,
        hometown: about.hometown,
        foundedYear: about.foundedYear,
        photoUrl: about.photoUrl || "",
        youtubeUrl: about.youtubeUrl || "",
        spotifyUrl: about.spotifyUrl || "",
        instagramUrl: about.instagramUrl || "",
      });
    }
  }, [about, form]);

  const onSubmit = (data: AboutForm) => {
    updateAbout.mutate({
      data: {
        ...data,
        photoUrl: data.photoUrl || null,
        youtubeUrl: data.youtubeUrl || null,
        spotifyUrl: data.spotifyUrl || null,
        instagramUrl: data.instagramUrl || null,
      }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetAboutQueryKey() });
        toast.success("About info updated!");
      },
      onError: (err) => toast.error(err.message)
    });
  };

  return (
    <AdminLayout>
      <h2 className="font-display text-4xl text-accent uppercase mb-8">Edit About Info</h2>

      {isLoading ? (
        <div className="flex justify-center p-8"><div className="animate-spin h-8 w-8 border-4 border-accent border-t-transparent rounded-full"></div></div>
      ) : (
        <div className="bg-card border-4 border-white p-6 shadow-[8px_8px_0_0_#fef6a7] -rotate-[0.5deg]">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField control={form.control} name="bandName" render={({ field }) => (
                  <FormItem><FormLabel>Band Name</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="tagline" render={({ field }) => (
                  <FormItem><FormLabel>Tagline</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="hometown" render={({ field }) => (
                  <FormItem><FormLabel>Hometown</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="foundedYear" render={({ field }) => (
                  <FormItem><FormLabel>Founded Year</FormLabel><FormControl><Input type="number" {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>

              <FormField control={form.control} name="story" render={({ field }) => (
                <FormItem><FormLabel>Story / Bio</FormLabel><FormControl><Textarea rows={8} {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
              )} />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t-2 border-dashed border-gray-600">
                <FormField control={form.control} name="photoUrl" render={({ field }) => (
                  <FormItem><FormLabel>Photo URL</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="youtubeUrl" render={({ field }) => (
                  <FormItem><FormLabel>YouTube URL</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="spotifyUrl" render={({ field }) => (
                  <FormItem><FormLabel>Spotify URL</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="instagramUrl" render={({ field }) => (
                  <FormItem><FormLabel>Instagram URL</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>

              <button type="submit" disabled={updateAbout.isPending} className="bg-accent text-black font-bold uppercase px-8 py-3 border-2 border-black shadow-[4px_4px_0_0_#000] hover:-translate-y-1 w-full mt-4 text-lg">
                Save About Info
              </button>
            </form>
          </Form>
        </div>
      )}
    </AdminLayout>
  );
}
