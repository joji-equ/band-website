import { AdminLayout } from "@/components/layout/AdminLayout";
import { useGetSummary } from "@workspace/api-client-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: summary, isLoading } = useGetSummary();

  return (
    <AdminLayout>
      <h2 className="font-display text-4xl mb-8 uppercase text-primary drop-shadow-md">Command Center</h2>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin h-12 w-12 border-8 border-accent border-t-transparent rounded-full"></div>
        </div>
      ) : summary ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <StatCard title="Total Shows" value={summary.showCount} color="bg-primary" route="/admin/shows" />
          <StatCard title="Upcoming Shows" value={summary.upcomingShowCount} color="bg-accent" route="/admin/shows" />
          <StatCard title="Albums" value={summary.albumCount} color="bg-secondary" route="/admin/albums" />
          <StatCard title="Singles" value={summary.singleCount} color="bg-white" route="/admin/singles" />
        </div>
      ) : null}

      {summary?.nextShow && (
        <div className="bg-card border-4 border-white p-6 shadow-[8px_8px_0px_0px_#ff6ec7] rotate-1 max-w-2xl">
          <span className="sticker-badge mb-2">NEXT SHOW</span>
          <h3 className="font-display text-2xl uppercase mt-2">{summary.nextShow.city}</h3>
          <p className="text-lg text-muted-foreground">{summary.nextShow.venue}</p>
          <p className="font-bold text-primary tracking-widest uppercase mt-2">
            {new Date(summary.nextShow.date).toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
          </p>
        </div>
      )}
    </AdminLayout>
  );
}

function StatCard({ title, value, color, route }: { title: string, value: number, color: string, route: string }) {
  return (
    <Link href={route} className={`${color} text-black p-6 border-4 border-black shadow-[6px_6px_0px_0px_#000] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_#000] transition-all flex flex-col justify-between block`}>
      <h3 className="font-bold uppercase tracking-widest text-sm mb-4">{title}</h3>
      <div className="font-display text-5xl">{value}</div>
    </Link>
  );
}
