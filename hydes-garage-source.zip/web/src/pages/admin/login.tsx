import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLogin, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const login = useLogin();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = (data: LoginForm) => {
    login.mutate({ data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        toast.success("Welcome to the backroom.");
        setLocation("/admin");
      },
      onError: (error) => {
        toast.error(error.message || "Failed to login. Check your credentials.");
      }
    });
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 pointer-events-none"></div>
      
      <Link href="/" className="absolute top-8 left-8 text-white uppercase font-bold hover:text-primary tracking-widest text-sm z-10">
        ← Back to site
      </Link>

      <div className="bg-card w-full max-w-md border-4 border-white p-8 shadow-[12px_12px_0px_0px_#ff6ec7] rotate-1 relative z-10">
        <div className="absolute -top-4 -left-4 w-12 h-12 bg-accent border-2 border-black rotate-12 flex items-center justify-center font-display text-2xl text-black shadow-[2px_2px_0_0_#000]">
          !
        </div>

        <h1 className="font-display text-4xl text-center mb-2 uppercase text-white">Authorized<br/>Personnel<br/>Only</h1>
        <p className="text-center text-muted-foreground mb-8 text-sm uppercase tracking-widest border-b-2 border-dashed border-gray-600 pb-4">Hydes Garage Admin</p>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="uppercase tracking-widest text-white text-xs">Username</FormLabel>
                  <FormControl>
                    <Input {...field} className="bg-black border-2 border-white text-white rounded-none h-12 focus-visible:ring-primary focus-visible:ring-offset-0 focus-visible:border-primary" />
                  </FormControl>
                  <FormMessage className="text-primary" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="uppercase tracking-widest text-white text-xs">Password</FormLabel>
                  <FormControl>
                    <Input type="password" {...field} className="bg-black border-2 border-white text-white rounded-none h-12 focus-visible:ring-primary focus-visible:ring-offset-0 focus-visible:border-primary" />
                  </FormControl>
                  <FormMessage className="text-primary" />
                </FormItem>
              )}
            />

            <button 
              type="submit" 
              disabled={login.isPending}
              className="w-full bg-white text-black font-display text-xl py-3 border-2 border-black shadow-[4px_4px_0_0_#baffc9] hover:translate-y-[2px] hover:shadow-[2px_2px_0_0_#baffc9] active:translate-y-[4px] active:shadow-none transition-all uppercase mt-4 disabled:opacity-50"
            >
              {login.isPending ? "Unlocking..." : "Enter"}
            </button>
          </form>
        </Form>
      </div>
    </div>
  );
}
