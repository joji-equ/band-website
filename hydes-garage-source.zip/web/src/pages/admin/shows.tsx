import { useState } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useListShows, useCreateShow, useUpdateShow, useDeleteShow, getListShowsQueryKey, getGetSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const showSchema = z.object({
  title: z.string().min(1, "Required"),
  venue: z.string().min(1, "Required"),
  city: z.string().min(1, "Required"),
  date: z.string().min(1, "Required"),
  ticketUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  notes: z.string().optional().or(z.literal("")),
});

type ShowForm = z.infer<typeof showSchema>;

export default function AdminShows() {
  const queryClient = useQueryClient();
  const { data: shows = [], isLoading } = useListShows();
  const createShow = useCreateShow();
  const updateShow = useUpdateShow();
  const deleteShow = useDeleteShow();

  const [editingId, setEditingId] = useState<number | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const form = useForm<ShowForm>({
    resolver: zodResolver(showSchema),
    defaultValues: { title: "", venue: "", city: "", date: "", ticketUrl: "", notes: "" }
  });

  const openCreate = () => {
    setEditingId(null);
    form.reset({ title: "", venue: "", city: "", date: "", ticketUrl: "", notes: "" });
    setIsFormOpen(true);
  };

  const openEdit = (show: any) => {
    setEditingId(show.id);
    // Format date for datetime-local input
    const dateObj = new Date(show.date);
    const tzoffset = dateObj.getTimezoneOffset() * 60000; // offset in milliseconds
    const localISOTime = (new Date(dateObj.getTime() - tzoffset)).toISOString().slice(0,16);

    form.reset({
      title: show.title,
      venue: show.venue,
      city: show.city,
      date: localISOTime,
      ticketUrl: show.ticketUrl || "",
      notes: show.notes || ""
    });
    setIsFormOpen(true);
  };

  const onSubmit = (data: ShowForm) => {
    const payload = {
      ...data,
      date: new Date(data.date).toISOString(), // ensure ISO format
      ticketUrl: data.ticketUrl || null,
      notes: data.notes || null,
    };

    if (editingId) {
      updateShow.mutate({ id: editingId, data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListShowsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() });
          toast.success("Show updated!");
          setIsFormOpen(false);
        },
        onError: (err) => toast.error(err.message)
      });
    } else {
      createShow.mutate({ data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListShowsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() });
          toast.success("Show created!");
          setIsFormOpen(false);
        },
        onError: (err) => toast.error(err.message)
      });
    }
  };

  const handleDelete = (id: number) => {
    deleteShow.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListShowsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() });
        toast.success("Show deleted.");
      },
      onError: (err) => toast.error(err.message)
    });
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <h2 className="font-display text-4xl text-primary uppercase">Manage Shows</h2>
        {!isFormOpen && (
          <button onClick={openCreate} className="bg-white text-black border-2 border-black font-bold uppercase px-4 py-2 shadow-[4px_4px_0_0_#baffc9] hover:translate-y-[2px] hover:shadow-[2px_2px_0_0_#baffc9]">
            + Add Show
          </button>
        )}
      </div>

      {isFormOpen ? (
        <div className="bg-card border-4 border-white p-6 shadow-[8px_8px_0_0_#ff6ec7] mb-8 rotate-[0.5deg]">
          <h3 className="font-display text-2xl uppercase mb-4">{editingId ? 'Edit Show' : 'New Show'}</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem><FormLabel>Tour/Show Title</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="date" render={({ field }) => (
                  <FormItem><FormLabel>Date & Time</FormLabel><FormControl><Input type="datetime-local" {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="venue" render={({ field }) => (
                  <FormItem><FormLabel>Venue</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="city" render={({ field }) => (
                  <FormItem><FormLabel>City</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="ticketUrl" render={({ field }) => (
                  <FormItem><FormLabel>Ticket URL (optional)</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="notes" render={({ field }) => (
                <FormItem><FormLabel>Notes (optional)</FormLabel><FormControl><Textarea {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="flex gap-4 pt-4">
                <button type="submit" disabled={createShow.isPending || updateShow.isPending} className="bg-primary text-black font-bold uppercase px-6 py-2 border-2 border-black shadow-[4px_4px_0_0_#000] hover:-translate-y-1">
                  Save Show
                </button>
                <button type="button" onClick={() => setIsFormOpen(false)} className="bg-white text-black font-bold uppercase px-6 py-2 border-2 border-black shadow-[4px_4px_0_0_#000] hover:-translate-y-1">
                  Cancel
                </button>
              </div>
            </form>
          </Form>
        </div>
      ) : (
        <div className="space-y-4">
          {isLoading ? (
             <div className="flex justify-center p-8"><div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div></div>
          ) : shows.length > 0 ? (
            shows.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(show => (
              <div key={show.id} className="flex flex-col sm:flex-row sm:items-center justify-between bg-black border-2 border-white p-4 hover:border-primary transition-colors">
                <div>
                  <div className="text-primary font-bold text-sm tracking-widest">{new Date(show.date).toLocaleString()}</div>
                  <div className="text-xl font-display uppercase">{show.title}</div>
                  <div className="text-muted-foreground">{show.venue} • {show.city}</div>
                </div>
                <div className="flex gap-2 mt-4 sm:mt-0">
                  <button onClick={() => openEdit(show)} className="bg-white text-black px-3 py-1 border-2 border-black font-bold text-sm uppercase shadow-[2px_2px_0_0_#000] hover:-translate-y-1">Edit</button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <button className="bg-destructive text-white px-3 py-1 border-2 border-black font-bold text-sm uppercase shadow-[2px_2px_0_0_#000] hover:-translate-y-1">Delete</button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-card border-4 border-white rounded-none">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="font-display uppercase text-2xl text-destructive">Delete Show?</AlertDialogTitle>
                        <AlertDialogDescription className="text-white">This cannot be undone. Are you sure?</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="rounded-none border-2 border-black text-black">Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(show.id)} className="bg-destructive text-white rounded-none border-2 border-black hover:bg-red-700">Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center p-12 border-4 border-dashed border-gray-700 text-gray-500 font-display text-2xl uppercase">No shows found.</div>
          )}
        </div>
      )}
    </AdminLayout>
  );
}
