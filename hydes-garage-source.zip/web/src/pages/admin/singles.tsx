import { useState } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { useListSingles, useCreateSingle, useUpdateSingle, useDeleteSingle, getListSinglesQueryKey, getGetSummaryQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const singleSchema = z.object({
  title: z.string().min(1, "Required"),
  releaseDate: z.string().min(1, "Required"),
  description: z.string().min(1, "Required"),
  coverUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  listenUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

type SingleForm = z.infer<typeof singleSchema>;

export default function AdminSingles() {
  const queryClient = useQueryClient();
  const { data: singles = [], isLoading } = useListSingles();
  const createSingle = useCreateSingle();
  const updateSingle = useUpdateSingle();
  const deleteSingle = useDeleteSingle();

  const [editingId, setEditingId] = useState<number | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);

  const form = useForm<SingleForm>({
    resolver: zodResolver(singleSchema),
    defaultValues: { title: "", releaseDate: "", description: "", coverUrl: "", listenUrl: "" }
  });

  const openCreate = () => {
    setEditingId(null);
    form.reset({ title: "", releaseDate: "", description: "", coverUrl: "", listenUrl: "" });
    setIsFormOpen(true);
  };

  const openEdit = (single: any) => {
    setEditingId(single.id);
    const dateObj = new Date(single.releaseDate);
    const tzoffset = dateObj.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(dateObj.getTime() - tzoffset)).toISOString().slice(0,16);

    form.reset({
      title: single.title,
      releaseDate: localISOTime,
      description: single.description,
      coverUrl: single.coverUrl || "",
      listenUrl: single.listenUrl || ""
    });
    setIsFormOpen(true);
  };

  const onSubmit = (data: SingleForm) => {
    const payload = {
      ...data,
      releaseDate: new Date(data.releaseDate).toISOString(),
      coverUrl: data.coverUrl || null,
      listenUrl: data.listenUrl || null,
    };

    if (editingId) {
      updateSingle.mutate({ id: editingId, data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSinglesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() });
          toast.success("Single updated!");
          setIsFormOpen(false);
        },
        onError: (err) => toast.error(err.message)
      });
    } else {
      createSingle.mutate({ data: payload }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSinglesQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() });
          toast.success("Single created!");
          setIsFormOpen(false);
        },
        onError: (err) => toast.error(err.message)
      });
    }
  };

  const handleDelete = (id: number) => {
    deleteSingle.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListSinglesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSummaryQueryKey() });
        toast.success("Single deleted.");
      },
      onError: (err) => toast.error(err.message)
    });
  };

  return (
    <AdminLayout>
      <div className="flex justify-between items-center mb-8">
        <h2 className="font-display text-4xl text-white uppercase">Manage Singles</h2>
        {!isFormOpen && (
          <button onClick={openCreate} className="bg-white text-black border-2 border-black font-bold uppercase px-4 py-2 shadow-[4px_4px_0_0_#fff] hover:translate-y-[2px] hover:shadow-[2px_2px_0_0_#fff]">
            + Add Single
          </button>
        )}
      </div>

      {isFormOpen ? (
        <div className="bg-card border-4 border-white p-6 shadow-[8px_8px_0_0_#fff] mb-8 rotate-[0.5deg]">
          <h3 className="font-display text-2xl uppercase mb-4">{editingId ? 'Edit Single' : 'New Single'}</h3>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField control={form.control} name="title" render={({ field }) => (
                  <FormItem><FormLabel>Single Title</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="releaseDate" render={({ field }) => (
                  <FormItem><FormLabel>Release Date</FormLabel><FormControl><Input type="datetime-local" {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="coverUrl" render={({ field }) => (
                  <FormItem><FormLabel>Cover Art URL</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="listenUrl" render={({ field }) => (
                  <FormItem><FormLabel>Streaming URL</FormLabel><FormControl><Input {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="description" render={({ field }) => (
                <FormItem><FormLabel>Description</FormLabel><FormControl><Textarea rows={4} {...field} className="bg-black border-white" /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="flex gap-4 pt-4">
                <button type="submit" disabled={createSingle.isPending || updateSingle.isPending} className="bg-white text-black font-bold uppercase px-6 py-2 border-2 border-black shadow-[4px_4px_0_0_#000] hover:-translate-y-1">
                  Save Single
                </button>
                <button type="button" onClick={() => setIsFormOpen(false)} className="bg-gray-300 text-black font-bold uppercase px-6 py-2 border-2 border-black shadow-[4px_4px_0_0_#000] hover:-translate-y-1">
                  Cancel
                </button>
              </div>
            </form>
          </Form>
        </div>
      ) : (
        <div className="space-y-4">
          {isLoading ? (
             <div className="flex justify-center p-8"><div className="animate-spin h-8 w-8 border-4 border-white border-t-transparent rounded-full"></div></div>
          ) : singles.length > 0 ? (
            singles.sort((a,b) => new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime()).map(single => (
              <div key={single.id} className="flex flex-col sm:flex-row sm:items-center justify-between bg-black border-2 border-white p-4 hover:border-white transition-colors">
                <div className="flex gap-4 items-center">
                  {single.coverUrl && <img src={single.coverUrl} alt={single.title} className="w-16 h-16 object-cover border-2 border-white" />}
                  <div>
                    <div className="text-white font-bold text-sm tracking-widest">{new Date(single.releaseDate).toLocaleDateString()}</div>
                    <div className="text-xl font-display uppercase">{single.title}</div>
                  </div>
                </div>
                <div className="flex gap-2 mt-4 sm:mt-0">
                  <button onClick={() => openEdit(single)} className="bg-white text-black px-3 py-1 border-2 border-black font-bold text-sm uppercase shadow-[2px_2px_0_0_#000] hover:-translate-y-1">Edit</button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <button className="bg-destructive text-white px-3 py-1 border-2 border-black font-bold text-sm uppercase shadow-[2px_2px_0_0_#000] hover:-translate-y-1">Delete</button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-card border-4 border-white rounded-none">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="font-display uppercase text-2xl text-destructive">Delete Single?</AlertDialogTitle>
                        <AlertDialogDescription className="text-white">This cannot be undone. Are you sure?</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="rounded-none border-2 border-black text-black">Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(single.id)} className="bg-destructive text-white rounded-none border-2 border-black hover:bg-red-700">Delete</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center p-12 border-4 border-dashed border-gray-700 text-gray-500 font-display text-2xl uppercase">No singles found.</div>
          )}
        </div>
      )}
    </AdminLayout>
  );
}
