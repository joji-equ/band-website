import { Navbar, Footer } from "@/components/layout/Navbar";
import { Link } from "wouter";
import bandPhoto from "@assets/band-photo_1777222042649.png";
import airbornePhoto from "@assets/album_1777221294892.jpg";
import { useListShows, useListAlbums } from "@workspace/api-client-react";

const LATEST_NOISE: Array<{ title: string; year: string; videoId: string; url: string }> = [
  {
    title: "Chronicles of a Dying Soul",
    year: "2025",
    videoId: "MFk2YqFuoMI",
    url: "https://www.youtube.com/watch?v=MFk2YqFuoMI",
  },
  {
    title: "Dear Ada",
    year: "2025",
    videoId: "emDVjypiajM",
    url: "https://www.youtube.com/watch?v=emDVjypiajM",
  },
];

export default function Home() {
  const { data: shows = [] } = useListShows();
  const { data: albums = [] } = useListAlbums();

  const upcomingShows = shows.filter(s => new Date(s.date) > new Date()).slice(0, 3);
  const latestAlbum = albums.length > 0 ? albums[albums.length - 1] : null;

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden">
      <Navbar />
      
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 grid grid-cols-1 md:grid-cols-3 gap-8 py-8">
        
        {/* Main Column */}
        <div className="md:col-span-2 space-y-12">
          
          <div className="flex justify-center -mt-16 mb-8 relative z-20">
            <div className="polaroid -rotate-3 hover:rotate-0 transition-transform duration-300 max-w-[240px]">
              <div className="border-4 border-black rounded-full overflow-hidden w-48 h-48 mx-auto mb-3">
                <img src={bandPhoto} alt="Hydes Garage" className="w-full h-full object-cover" />
              </div>
              <div className="uppercase">Serkawn, MZ • Est. 2020</div>
            </div>
          </div>

          {latestAlbum && (
            <article className="zine-card">
              <h2 className="text-3xl text-accent mb-2">{latestAlbum.title}</h2>
              <div className="text-primary mb-4 font-bold uppercase tracking-widest text-sm">
                Released {new Date(latestAlbum.releaseDate).toLocaleDateString()}
              </div>
              <div className="flex flex-col sm:flex-row gap-6">
                <div className="w-48 h-48 border-4 border-black shadow-[6px_6px_0px_0px_#000] -rotate-2 flex-shrink-0">
                  <img src={latestAlbum.coverUrl || airbornePhoto} alt={latestAlbum.title} className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className="sticker-badge mb-2">LATEST ALBUM</span>
                  <p className="text-lg leading-relaxed">{latestAlbum.description}</p>
                  {latestAlbum.listenUrl && (
                    <a href={latestAlbum.listenUrl} target="_blank" rel="noreferrer" className="zine-button inline-block mt-4 px-4 py-2">Listen Now</a>
                  )}
                </div>
              </div>
            </article>
          )}

          <article className="zine-card-alt">
            <h2 className="text-3xl text-secondary mb-6">Latest Noise</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {LATEST_NOISE.map((track, idx) => (
                <a
                  key={track.videoId}
                  href={track.url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex gap-4 group"
                >
                  <div className={`w-24 h-24 border-2 border-black flex-shrink-0 overflow-hidden ${idx % 2 === 0 ? 'rotate-2' : '-rotate-2'} group-hover:rotate-0 transition-transform`}>
                    <img
                      src={`https://i.ytimg.com/vi/${track.videoId}/hqdefault.jpg`}
                      alt={track.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <span className="sticker-badge mb-1">TRACK</span>
                    <h3 className="font-display text-xl text-white group-hover:text-primary">{track.title}</h3>
                    <p className="text-sm text-muted-foreground">{track.year}</p>
                  </div>
                </a>
              ))}
            </div>
          </article>
        </div>

        {/* Sidebar Column */}
        <aside className="space-y-8">
          <div className="bg-accent text-black p-6 border-4 border-black shadow-[8px_8px_0px_0px_#000] rotate-1">
            <h3 className="font-display text-2xl mb-4 uppercase">⚠ Upcoming Shows</h3>
            {upcomingShows.length > 0 ? (
              <ul className="space-y-4">
                {upcomingShows.map(show => (
                  <li key={show.id} className="border-b-2 border-dashed border-black pb-4 last:border-0 last:pb-0">
                    <div className="font-bold text-lg">{show.city}</div>
                    <div className="text-sm">{show.venue} • {new Date(show.date).toLocaleDateString()}</div>
                    {show.ticketUrl && (
                      <a href={show.ticketUrl} target="_blank" rel="noreferrer" className="text-primary hover:underline text-sm font-bold uppercase mt-1 block">Get Tickets</a>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="polaroid -rotate-2">
                <div className="bg-gray-200 h-24 flex items-center justify-center mb-2 border-2 border-black">
                  <span className="text-4xl text-gray-400">?</span>
                </div>
                <p>No shows on the calendar... yet. Check back soon.</p>
              </div>
            )}
            <div className="mt-4 pt-4 border-t-4 border-black">
               <Link href="/shows" className="font-bold hover:text-primary uppercase tracking-wider block text-center">View All Shows →</Link>
            </div>
          </div>

          <div className="bg-primary text-black p-6 border-4 border-black shadow-[8px_8px_0px_0px_#000] -rotate-1">
            <h3 className="font-display text-2xl mb-4 uppercase">🎶 Listen Here</h3>
            <div className="space-y-3">
              <a href="https://www.youtube.com/channel/UC4Y2eWYNrNqfYc7TB3Uq7Zw" target="_blank" rel="noreferrer" className="zine-button block text-center px-4 py-3 text-lg">▶ YouTube</a>
              <a href="https://open.spotify.com/album/0tOwePe5BQlsw2SWtUcOC8" target="_blank" rel="noreferrer" className="zine-button block text-center px-4 py-3 text-lg">🎧 Spotify</a>
              <a href="https://www.instagram.com/hydesgarage?igsh=MTg2OXBhODF2ZGV4cw==" target="_blank" rel="noreferrer" className="zine-button block text-center px-4 py-3 text-lg">📸 Instagram</a>
            </div>
          </div>
        </aside>

      </main>
      
      <Footer />
    </div>
  );
}
