import { Navbar, Footer } from "@/components/layout/Navbar";
import { useListAlbums, useListSingles } from "@workspace/api-client-react";
import airbornePhoto from "@assets/album_1777221294892.jpg";
import kathianPhoto from "@assets/single_kathian.png";
import { getYouTubeEmbedUrl } from "@/lib/youtube";

const FEATURED_TRACK = {
  title: "Dear Ada",
  album: "Airborne Deceptions",
  trackNumber: 8,
  videoId: "emDVjypiajM",
  playlistId: "PLJc5bhfPLwWhWpjC04Ri2V6U4UEdPDMNl",
};

export default function Music() {
  const { data: albums = [], isLoading: isLoadingAlbums } = useListAlbums();
  const { data: singles = [], isLoading: isLoadingSingles } = useListSingles();

  const allMusic = [
    ...albums.map((a) => ({ ...a, type: "ALBUM" as const })),
    ...singles.map((s) => ({ ...s, type: "SINGLE" as const })),
  ].sort(
    (a, b) => new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime(),
  );

  const isLoading = isLoadingAlbums || isLoadingSingles;

  const featuredEmbed = `https://www.youtube.com/embed/${FEATURED_TRACK.videoId}?list=${FEATURED_TRACK.playlistId}`;
  const featuredWatch = `https://www.youtube.com/watch?v=${FEATURED_TRACK.videoId}&list=${FEATURED_TRACK.playlistId}&index=${FEATURED_TRACK.trackNumber}`;

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden">
      <Navbar />

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-12">
        <h2 className="font-display text-5xl text-secondary mb-12 rotate-1 text-center uppercase shadow-black drop-shadow-md">
          Discography
        </h2>

        {/* Featured track */}
        <section className="mb-20">
          <div className="flex items-center gap-3 mb-6">
            <span className="sticker-badge bg-yellow-300 text-black -rotate-3">
              Featured Track
            </span>
            <span className="font-display text-2xl text-secondary -rotate-1">
              now playing
            </span>
          </div>
          <div className="bg-card border-4 border-white p-6 -rotate-1 shadow-[10px_10px_0px_0px_#ff6ec7] relative">
            <div className="absolute -top-3 left-8 w-16 h-5 bg-white/60 rotate-[-6deg]"></div>
            <div className="absolute -top-3 right-8 w-16 h-5 bg-white/60 rotate-[4deg]"></div>
            <div className="grid md:grid-cols-2 gap-6 items-center">
              <div className="border-4 border-black bg-black">
                <div className="relative w-full" style={{ paddingBottom: "56.25%" }}>
                  <iframe
                    className="absolute inset-0 w-full h-full"
                    src={featuredEmbed}
                    title={FEATURED_TRACK.title}
                    loading="lazy"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              </div>
              <div>
                <div className="text-muted-foreground tracking-widest text-sm mb-2">
                  TRACK {String(FEATURED_TRACK.trackNumber).padStart(2, "0")} ·{" "}
                  {FEATURED_TRACK.album}
                </div>
                <h3 className="font-display text-4xl text-primary uppercase mb-3">
                  {FEATURED_TRACK.title}
                </h3>
                <p className="text-lg leading-relaxed mb-6">
                  Our pick of the moment. Hit play, turn it up, let it run into the
                  rest of the album.
                </p>
                <a
                  href={featuredWatch}
                  target="_blank"
                  rel="noreferrer"
                  className="zine-button inline-block px-6 py-2 uppercase tracking-wider"
                >
                  Open on YouTube
                </a>
              </div>
            </div>
          </div>
        </section>

        {isLoading ? (
          <div className="flex justify-center p-12">
            <div className="animate-spin h-12 w-12 border-8 border-secondary border-t-black rounded-full"></div>
          </div>
        ) : allMusic.length > 0 ? (
          <div className="space-y-16">
            {allMusic.map((item, i) => {
              const embedUrl = getYouTubeEmbedUrl(item.listenUrl);
              const reverse = i % 2 !== 0;
              const fallbackCover =
                item.type === "ALBUM" ? airbornePhoto : null;
              const coverSrc = item.coverUrl || fallbackCover;
              const showCover = Boolean(coverSrc);

              return (
                <div
                  key={`${item.type}-${item.id}`}
                  className={`flex flex-col md:flex-row gap-8 items-start ${
                    reverse ? "md:flex-row-reverse" : ""
                  }`}
                >
                  {/* Left/right column: cover + (optional) embed stacked */}
                  <div className="flex-shrink-0 w-full md:w-80 space-y-6">
                    {showCover && (
                      <div
                        className={`w-64 h-64 mx-auto md:mx-0 border-4 border-black relative ${
                          reverse
                            ? "rotate-2 shadow-[8px_8px_0px_0px_#baffc9]"
                            : "-rotate-2 shadow-[8px_8px_0px_0px_#ff6ec7]"
                        }`}
                      >
                        <div
                          className={`absolute -top-4 ${
                            reverse ? "-left-4 -rotate-12" : "-right-4 rotate-12"
                          } w-12 h-4 bg-white/60 z-10`}
                        ></div>
                        <img
                          src={coverSrc!}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {embedUrl && (
                      <div
                        className={`border-4 border-black bg-black ${
                          reverse ? "-rotate-1" : "rotate-1"
                        }`}
                      >
                        <div
                          className="relative w-full"
                          style={{ paddingBottom: "56.25%" }}
                        >
                          <iframe
                            className="absolute inset-0 w-full h-full"
                            src={embedUrl}
                            title={item.title}
                            loading="lazy"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div
                    className={`flex-1 bg-card border-4 border-white p-6 ${
                      reverse ? "-rotate-1" : "rotate-1"
                    } relative`}
                  >
                    <div className="absolute top-0 right-0 p-2">
                      <span className="sticker-badge">{item.type}</span>
                    </div>
                    <h3 className="font-display text-3xl text-primary mb-2 uppercase">
                      {item.title}
                    </h3>
                    <div className="text-muted-foreground font-bold tracking-widest mb-4 border-b-2 border-dashed border-gray-600 pb-2 inline-block">
                      {new Date(item.releaseDate).toLocaleDateString(undefined, {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </div>
                    <p className="text-lg leading-relaxed whitespace-pre-wrap">
                      {item.description}
                    </p>

                    {item.listenUrl && (
                      <div className="mt-6 pt-4 border-t-2 border-dashed border-gray-600">
                        <a
                          href={item.listenUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="zine-button inline-block px-6 py-2 uppercase tracking-wider"
                        >
                          {embedUrl ? "Open on YouTube" : "Listen"}
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex justify-center">
            <div className="polaroid -rotate-2 max-w-sm">
              <div className="bg-gray-200 h-32 flex items-center justify-center mb-2 border-2 border-black">
                <span className="text-5xl text-gray-400">?</span>
              </div>
              <p className="text-lg">
                No music released yet.
                <br />
                Still recording in the bedroom.
              </p>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
