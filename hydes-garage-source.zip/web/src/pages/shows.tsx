import { Navbar, Footer } from "@/components/layout/Navbar";
import { useListShows } from "@workspace/api-client-react";
import { buildGoogleCalendarUrl } from "@/lib/calendar";

export default function Shows() {
  const { data: shows = [], isLoading } = useListShows();
  
  const upcomingShows = shows.filter(s => new Date(s.date) > new Date()).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const pastShows = shows.filter(s => new Date(s.date) <= new Date()).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden">
      <Navbar />
      
      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-12">
        <h2 className="font-display text-5xl text-primary mb-12 -rotate-2 text-center uppercase shadow-black drop-shadow-md">Tour Chaos</h2>
        
        <section className="mb-16">
          <div className="bg-accent p-4 inline-block border-4 border-black rotate-1 mb-8">
            <h3 className="font-display text-3xl text-black uppercase m-0">⚠ Upcoming Dates</h3>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center p-12">
              <div className="animate-spin h-12 w-12 border-8 border-primary border-t-black rounded-full"></div>
            </div>
          ) : upcomingShows.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {upcomingShows.map((show, i) => {
                const calendarUrl = buildGoogleCalendarUrl({
                  title: `Hydes Garage — ${show.title}`,
                  start: show.date,
                  durationMinutes: 120,
                  location: `${show.venue}, ${show.city}`,
                  details: show.notes ?? undefined,
                });
                return (
                  <div key={show.id} className={`bg-white text-black p-6 border-4 border-black shadow-[8px_8px_0px_0px_#000] relative flex flex-col ${i % 2 === 0 ? '-rotate-1' : 'rotate-2'}`}>
                    {/* Tape top center */}
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-16 h-6 bg-yellow-200/80 -rotate-3 z-10"></div>

                    <div className="text-primary font-bold uppercase tracking-widest border-b-2 border-dashed border-black pb-2 mb-4">
                      {new Date(show.date).toLocaleDateString(undefined, { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' })}
                    </div>
                    <h4 className="font-display text-2xl uppercase mb-1">{show.city}</h4>
                    <div className="text-xl mb-4">{show.venue}</div>
                    {show.notes && <div className="text-sm italic mb-4 bg-gray-100 p-2 border border-black">{show.notes}</div>}
                    <a
                      href={calendarUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="zine-button block text-center py-2 mt-auto uppercase tracking-wider"
                    >
                      Add to Calendar
                    </a>
                  </div>
                );
              })}
            </div>
          ) : (
             <div className="flex justify-center">
              <div className="polaroid -rotate-2 max-w-sm">
                <div className="bg-gray-200 h-32 flex items-center justify-center mb-2 border-2 border-black">
                  <span className="text-5xl text-gray-400">?</span>
                </div>
                <p className="text-lg">No upcoming shows right now.<br/>We're probably sleeping.</p>
              </div>
             </div>
          )}
        </section>

        <section>
          <div className="bg-primary p-4 inline-block border-4 border-black -rotate-1 mb-8 text-black">
            <h3 className="font-display text-3xl uppercase m-0">Past Gigs</h3>
          </div>
          
          {pastShows.length > 0 ? (
            <ul className="space-y-4">
              {pastShows.map(show => (
                <li key={show.id} className="flex flex-col sm:flex-row sm:items-center justify-between bg-card text-card-foreground border-2 border-black p-4 rotate-[0.5deg] hover:bg-muted transition-colors">
                  <div>
                    <span className="text-primary font-bold mr-4">{new Date(show.date).toLocaleDateString()}</span>
                    <strong className="text-lg uppercase">{show.city}</strong> <span className="mx-2">—</span> {show.venue}
                  </div>
                </li>
              ))}
            </ul>
          ) : null}
        </section>

      </main>
      
      <Footer />
    </div>
  );
}
